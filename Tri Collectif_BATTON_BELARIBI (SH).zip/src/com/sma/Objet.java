package com.sma;

public class Objet {

    private String type;

    public Objet(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}

package com.sma;

public class Main {

    public static void main(String args[]) {

        Board.createInstance(50, 50, 20, 200, 200, 4, 0.1f, 0.3f, 10_000_000, 0.01f, 10);
    }
}
